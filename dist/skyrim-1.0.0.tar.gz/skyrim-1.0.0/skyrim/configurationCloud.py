import os

SKYRIM_CONST_CALENDAR_PATH = os.path.join("E:\\", "Database", "Calendar", "cne_calendar.csv")
SKYRIM_CONST_INSTRUMENT_INFO_PATH = os.path.join("E:\\", "Deploy", "User", "InstrumentInfo")
