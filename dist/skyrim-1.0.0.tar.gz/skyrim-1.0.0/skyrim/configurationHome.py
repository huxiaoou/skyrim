import os

SKYRIM_CONST_CALENDAR_PATH = os.path.join("C:\\", "Users", "huxia", "OneDrive", "文档", "Trading", "Database", "Calendar", "cne_calendar.csv")
SKYRIM_CONST_CALENDAR_DIR = os.path.join("D:\\", "DataBaseCTP")
SKYRIM_CONST_INSTRUMENT_INFO_PATH = os.path.join("C:\\", "Users", "huxia", "OneDrive", "文档", "Trading", "Database", "Futures", "InstrumentInfo.xlsx")
